Cleaned STL files for drone_rubber.zip

*_clean.stl: duplicate/degenerate faces removed where present; original orientation kept.
*_clean_oriented_prusa.stl: same cleaned mesh, rotated +90 degrees around X so original Y becomes printer Z, then moved to Z=0. This gives the front/rear parts a much larger flat contact area and low support risk.

Recommended first try in PrusaSlicer:
- Material: TPU/TPE if the part really should behave like rubber. PLA/PETG will print easier but will not be rubber-like.
- Orientation: use the *_clean_oriented_prusa.stl files first.
- Add a brim for TPU and small contact patches.
- Low print speed for TPU, dry filament, avoid crossing perimeters if stringing is bad.
- Check rear_rubber visually: it contains two separate watertight shells. I preserved both because it may be intentional, but verify in slicer preview before printing.
